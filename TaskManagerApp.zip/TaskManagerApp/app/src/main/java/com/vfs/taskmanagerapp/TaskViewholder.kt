package com.vfs.taskmanagerapp

import android.view.View
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Holds Task View elements
class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
{
    val taskCheckBox: CheckBox = itemView.findViewById(R.id.taskCheckBox_id)
    val descriptionTextView: TextView = itemView.findViewById(R.id.descriptionTextView_id)
    val editTaskButton: ImageButton = itemView.findViewById(R.id.editTaskButton_id)
    val deleteTaskButton: ImageButton = itemView.findViewById(R.id.deleteTaskButton_id)
}
