package com.vfs.taskmanagerapp

// Class to create each task
data class Task(
                val task: String,
                val description: String,
                var isCompleted: Boolean = false
)