package com.vfs.taskmanagerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ToggleButton
import com.google.firebase.auth.UserProfileChangeRequest

class LoginRegisterActivity : AppCompatActivity() {

    lateinit var loginButton: Button
    lateinit var registerButton: Button

    lateinit var nameRegisterEditText: EditText
    lateinit var emailRegisterEditText: EditText
    lateinit var passwordRegisterEditText: EditText

    lateinit var emailLoginEditText: EditText
    lateinit var passwordLoginEditText: EditText

    lateinit var statusText: TextView

    private fun setupClickListener() {
        loginButton = findViewById(R.id.btnLoginSubmit)
        registerButton = findViewById(R.id.btnRegisterSubmit)

        nameRegisterEditText = findViewById(R.id.registerName)
        emailRegisterEditText = findViewById(R.id.registerEmail)
        passwordRegisterEditText = findViewById(R.id.registerPassword)

        emailLoginEditText = findViewById(R.id.loginEmail)
        passwordLoginEditText = findViewById(R.id.loginPassword)

        statusText = findViewById(R.id.statusTextView)

        registerButton.setOnClickListener {
            handleRegister()
        }

        loginButton.setOnClickListener() {
            handleLogin()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.login_register_layout)

        ToggleRegister()
        setupClickListener()

        fun setupListeners() {
            // Action button listener (Login/Register)
            registerButton.setOnClickListener {
                handleRegister()
            }
        }
    }

    fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun handleRegister() {
        val username = nameRegisterEditText.text.toString().trim()
        val email = emailRegisterEditText.text.toString().trim()
        val password = passwordRegisterEditText.text.toString().trim()

        when {
            username.isEmpty() -> {
                statusText.text = "Please enter a username"
            }

            email.isEmpty() -> {
                statusText.text = "Please enter an email"
            }

            password.isEmpty() -> {
                statusText.text = "Please enter a password"
            }

            !isValidEmail(email) -> {
                statusText.text = "Please enter a valid email"
            }

            password.length < 6 -> {
                statusText.text = "Password must be at least 6 characters"
            }

            else -> {
                statusText.text = "Registration successful for $username!"

                Cloud.auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            val profileUpdates = UserProfileChangeRequest.Builder()
                                .setDisplayName(username)
                                .build()

                            Cloud.auth.currentUser?.updateProfile(profileUpdates)
                                ?.addOnCompleteListener(this) { profTask ->
                                if (profTask.isSuccessful) {
                                    Cloud.writeUserAfterRegistration()
                                    Cloud.writeUserObjectAfterRegistration()

                                    val intent = Intent(this, TaskManager::class.java)
                                    startActivity(intent)
                                    finish()
                                }
                                else { }
                            }
                        } else {
                            statusText.text = "Registration failed: ${task.exception?.message}"
                        }
                    }
            }
        }
    }

    fun handleLogin() {
        val email = emailLoginEditText.text.toString().trim()
        val password = passwordLoginEditText.text.toString().trim()

        when {
            email.isEmpty() -> {
                statusText.text = "Please enter an email"
            }
            password.isEmpty() -> {
                statusText.text = "Please enter a password"
            }
            !isValidEmail(email) -> {
                statusText.text = "Please enter a valid email"
            }
            else -> {
                statusText.text = "Login successful for $email!"

                Cloud.auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener (this) { task ->
                        if (task.isSuccessful) {
                            statusText.text = "Login successful for $email!"
                            val profileUpdates = UserProfileChangeRequest.Builder()
                                .setDisplayName(Cloud.auth.currentUser?.displayName)
                                .build()

                            Cloud.auth.currentUser?.updateProfile(profileUpdates)

                            val intent = Intent(this, TaskManager::class.java)
                            startActivity(intent)
                            finish()
                        }
                        else{
                            statusText.text = "Registration failed: ${task.exception?.message}"
                        }

                    }
            }
        }
    }

    fun ToggleRegister()
    {
        val toggleLogin = findViewById<ToggleButton>(R.id.toggleLogin)
        val toggleRegister = findViewById<ToggleButton>(R.id.toggleRegister)
        val loginSection = findViewById<LinearLayout>(R.id.loginSection)
        val registerSection = findViewById<LinearLayout>(R.id.registerSection)

        toggleLogin.setOnClickListener {
            toggleLogin.isChecked = true
            toggleRegister.isChecked = false
            loginSection.visibility = View.VISIBLE
            registerSection.visibility = View.GONE
        }

        toggleRegister.setOnClickListener {
            toggleLogin.isChecked = false
            toggleRegister.isChecked = true
            loginSection.visibility = View.GONE
            registerSection.visibility = View.VISIBLE
        }
    }

    private fun clearFields() {
        nameRegisterEditText.text.clear()
        emailRegisterEditText.text.clear()
        passwordRegisterEditText.text.clear()
    }

}