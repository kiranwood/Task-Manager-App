package com.vfs.taskmanagerapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener


fun TaskManager.showLoginRegisterModal ()
{
    val builder = AlertDialog.Builder(this)

    builder.setTitle("Login or Register")
    builder.setMessage("Would you like to login or register?")


    builder.setPositiveButton("Login") { _, _ ->
        val intent = Intent(this, LoginRegisterActivity::class.java)
        intent.putExtra("type", "login")
        startActivity(intent)
        finish()
    }

    builder.setNegativeButton("Register") { _, _ ->
        val intent = Intent(this, LoginRegisterActivity::class.java)
        intent.putExtra("type", "register")
        startActivity(intent)
        finish()
    }

    builder.setNeutralButton("Cancel" ) { _, _ ->

    }

    val dialog = builder.create()
    dialog.show()

    dialog.window?.setGravity((Gravity.TOP))
}

fun TaskManager.showLogoutButton ()
{
    val builder = AlertDialog.Builder(this)

    builder.setTitle("Log Out")
    builder.setMessage("Are you sure you want to log out?")


    builder.setPositiveButton("Logout") { _, _ ->
        Cloud.auth.signOut()

        checkOnlineStatus()
    }

    builder.setNegativeButton("Cancel") { _, _ ->
    }

    val dialog = builder.create()
    dialog.show()

    dialog.window?.setGravity((Gravity.TOP))
}

fun readTask(task : Task)
{
    Cloud.auth.currentUser?.let {
        Cloud.db.reference
            .child("users")
            .child(it.uid)
            .child("tasks")
            .setValue(task.task)
        Cloud.db.reference
            .child("users")
            .child(it.uid)
            .child("tasks")
            .child(task.task)
            .child("description")
            .setValue(task.description)
    }
}


class TaskManager : AppCompatActivity()
{
    lateinit var statusButton: Button

    fun checkOnlineStatus()
    {
        statusButton.text = "We are offline"
        statusButton.setBackgroundColor(Color.YELLOW)

        Cloud.auth.currentUser?.let {
            statusButton.text = "${it.displayName} is online"
            statusButton.setBackgroundColor(Color.GREEN)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_task_manager)

        // Gets each view element
        val headerTextView = findViewById<TextView>(R.id.headerTextView)
        val taskEditText = findViewById<EditText>(R.id.taskEditText_id)
        val descriptionEditText = findViewById<EditText>(R.id.descriptionEditText_id)
        val saveTaskButton = findViewById<Button>(R.id.saveTaskButton_id)
        val viewTaskButton = findViewById<Button>(R.id.viewTasksButton_id)

        statusButton = findViewById(R.id.statusButton_id)
        statusButton.setOnClickListener {
            if (Cloud.auth.currentUser == null)
                showLoginRegisterModal()
            else
                showLogoutButton()
        }
        Cloud.auth = FirebaseAuth.getInstance()
        checkOnlineStatus()

        // Check if editing a task
        val editPosition = intent.getIntExtra("task_position", -1)
        val isEditMode = editPosition != -1

        // If it is in edit mode
        if (isEditMode)
        {
            // Changes header and button text
            headerTextView.text = "Edit Task"
            saveTaskButton.text = "Update Task"

            // Changes the header and description text to task data
            taskEditText.setText(intent.getStringExtra("task_title"))
            descriptionEditText.setText(intent.getStringExtra("task_description"))
        }

        // Saves / updates the task
        saveTaskButton.setOnClickListener {

            // Gets the text of the title and description
            val taskTitle = taskEditText.text.toString()
            val taskDescription = descriptionEditText.text.toString()

            // Checks if title is not empty
            if (taskTitle.isNotBlank())
            {
                // Creates a new task
                val updatedTask = Task(taskTitle, taskDescription)

                // Checks if editing a task or creating a new one
                if (isEditMode)
                {
                    // Updates task
                    TaskRepository.updateTask(editPosition, updatedTask)

                    // Lets user know task was updated
                    Toast.makeText(this, "Task Updated!", Toast.LENGTH_SHORT).show()

                    // Return to list after editing
                    val intent = Intent(this, TaskListScreen::class.java)
                    startActivity(intent)
                    finish()
                }
                else if (TaskRepository.checkTask(updatedTask)) // Checks if task already exists
                {
                    Toast.makeText(this, "Task Already Exists", Toast.LENGTH_SHORT).show()
                }
                else // Creates new task
                {
                    // Adds new task
                    TaskRepository.addTask(updatedTask)
                    readTask(updatedTask)

                    // Clears the text of title and description
                    taskEditText.text.clear()
                    descriptionEditText.text.clear()

                    // Alerts user that task was saved
                    Toast.makeText(this, "Task Saved!", Toast.LENGTH_SHORT).show()
                }
            }
            else // Task was empty
            {
                // Lets user know task title cant be empty
                Toast.makeText(this, "Give your task a title", Toast.LENGTH_SHORT).show()
            }
        }

        // Moves to task list screen
        viewTaskButton.setOnClickListener {
            val intent = Intent(this, TaskListScreen::class.java)
            startActivity(intent)
            finish()
        }
    }
}