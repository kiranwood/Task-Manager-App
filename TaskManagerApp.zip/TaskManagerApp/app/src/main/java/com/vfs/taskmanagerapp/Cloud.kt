package com.vfs.taskmanagerapp

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.database


class Cloud
{
    companion object
    {
        lateinit var auth: FirebaseAuth
        val db = Firebase.database

        fun writeUserAfterRegistration()
        {
            auth.currentUser?.let {
                val id = it.uid // get the current user's id

                val userDict = hashMapOf("name" to it.displayName,
                    "email" to it.email,
                    "id" to it.uid )

                db.getReference("users")
                    .child(id)
                    .setValue(userDict)  {error, ref ->
                        if (error != null)
                        {
                            Log.e("Database Error", error.toString())
                        }
                    }
            }
        }

        fun writeUserObjectAfterRegistration()
        {
            auth.currentUser?.let {
                val user =  User (it.displayName, it.email, it.uid)

                val completionListener = DatabaseReference.CompletionListener { error, ref ->
                    if (error != null)
                    {
                        Log.e("Database Error", error.toString())
                    }
                }

                db.getReference("players")
                    .child(it.uid)
                    .setValue(user, completionListener)
            }
        }
    }
}