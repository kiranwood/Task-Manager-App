package com.vfs.taskmanagerapp

// Holds all the task data and functions
object TaskRepository {

    // A list of all the tasks
    val tasks = mutableListOf<Task>()

    // Adds a task to the list
    fun addTask(task: Task)
    {
        tasks.add(task)
    }

    // Checks if a task already exists
    fun checkTask(task: Task) : Boolean
    {
        for (existingTask in tasks)
        {
            if (existingTask.task.lowercase() contentEquals  task.task.lowercase())
            {
                return true; // Task already exists
            }
        }
        return false; // Task does not exist
    }

    // Deletes a task from the list
    fun deleteTask(position: Int)
    {
        if (position >= 0 && position < tasks.size)
        {
            tasks.removeAt(position)
        }
    }

    // Updates a task in the list
    fun updateTask(position: Int, task: Task)
    {
        if (position >= 0 && position < tasks.size)
        {
            tasks[position] = task
        }
    }
}
