package com.vfs.taskmanagerapp

import android.graphics.Color

fun TaskManager.checkOnlineStatus()
{
    // Shows no user online
    statusButton.text = "We are offline"
    statusButton.setBackgroundColor(Color.YELLOW)

    // Checks for user
    Cloud.auth.currentUser?.let {
        statusButton.text = "${it.displayName} is online"
        statusButton.setBackgroundColor(Color.GREEN)
    }
}
