package com.vfs.taskmanagerapp

class User {
    var name: String? = null
    var email: String? = null
    var id: String = ""

    constructor(n: String?, e: String?, i: String)
    {
        this.name = n
        this.email = e
        this.id = i
    }

    constructor(map: Map<String, String>)
    {
        map["name"]?.let {this.name = it}
        map["email"]?.let {this.email = it}
        map["id"]?.let {this.id = it}
    }
}