package com.vfs.taskmanagerapp

import android.view.View
import android.widget.LinearLayout
import android.widget.ToggleButton

fun LoginRegisterActivity.toggleRegister()
{
    // Gets buttons and layouts
    val toggleLogin = findViewById<ToggleButton>(R.id.toggleLogin)
    val toggleRegister = findViewById<ToggleButton>(R.id.toggleRegister)
    val loginSection = findViewById<LinearLayout>(R.id.loginSection)
    val registerSection = findViewById<LinearLayout>(R.id.registerSection)

    // Shows screen in login
    toggleLogin.setOnClickListener {
        toggleLogin.isChecked = true
        toggleRegister.isChecked = false
        loginSection.visibility = View.VISIBLE
        registerSection.visibility = View.GONE
    }

    // Shows screen in register
    toggleRegister.setOnClickListener {
        toggleLogin.isChecked = false
        toggleRegister.isChecked = true
        loginSection.visibility = View.GONE
        registerSection.visibility = View.VISIBLE
    }
}