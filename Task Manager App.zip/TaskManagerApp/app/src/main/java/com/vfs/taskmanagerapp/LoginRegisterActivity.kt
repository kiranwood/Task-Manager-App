package com.vfs.taskmanagerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ToggleButton
import com.google.firebase.auth.UserProfileChangeRequest

class LoginRegisterActivity : AppCompatActivity() {

    lateinit var loginButton: Button
    lateinit var registerButton: Button

    lateinit var nameRegisterEditText: EditText
    lateinit var emailRegisterEditText: EditText
    lateinit var passwordRegisterEditText: EditText

    lateinit var emailLoginEditText: EditText
    lateinit var passwordLoginEditText: EditText

    lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.login_register_layout)

        toggleRegister()
        setupClickListener()

        // Handle intent extra to show initial screen
        val initialScreen = intent.getStringExtra("type")

        if (initialScreen == "register") {
            findViewById<ToggleButton>(R.id.toggleRegister).performClick()
        }
    }

    fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}