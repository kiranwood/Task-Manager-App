package com.vfs.taskmanagerapp

import android.view.Gravity
import androidx.appcompat.app.AlertDialog

fun TaskManager.showLogoutButton ()
{
    val builder = AlertDialog.Builder(this)

    // Shows text to log out
    builder.setTitle("Log Out")
    builder.setMessage("Are you sure you want to log out?")

    // Logout button
    builder.setPositiveButton("Logout") { _, _ ->
        Cloud.auth.signOut()
        TaskRepository.tasks.clear()
        checkOnlineStatus()
    }

    // Cancels popup
    builder.setNegativeButton("Cancel") { _, _ ->
    }

    // Shows the popup on the screen
    val dialog = builder.create()
    dialog.show()

    dialog.window?.setGravity((Gravity.TOP))
}