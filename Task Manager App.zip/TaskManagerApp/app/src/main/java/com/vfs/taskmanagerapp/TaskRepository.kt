package com.vfs.taskmanagerapp

// Holds all the task data and functions

fun writeTask(task : Task)
{
    // Writes all the data for the tasks
    Cloud.auth.currentUser?.let {
        Cloud.db.reference
            .child("users")
            .child(it.uid)
            .child("task-list")
            .child(task.id)
            .child("task-name")
            .setValue(task.task)
        Cloud.db.reference
            .child("users")
            .child(it.uid)
            .child("task-list")
            .child(task.id)
            .child("description")
            .setValue(task.description)
        Cloud.db.reference
            .child("users")
            .child(it.uid)
            .child("task-list")
            .child(task.id)
            .child("is-completed")
            .setValue(task.isCompleted)
    }
}
object TaskRepository {

    // A list of all the tasks
    val tasks = mutableListOf<Task>()

    fun clearTasks() {
        tasks.clear()
    }

    fun fetchTasksFromCloud(onComplete: () -> Unit) {
        val currentUser = Cloud.auth.currentUser
        if (currentUser != null) {
            val taskRef = Cloud.db.reference
                .child("users")
                .child(currentUser.uid)
                .child("task-list")

            // Gets all tasks
            taskRef.get().addOnSuccessListener { snapshot ->

                // Clears current tasks list
                tasks.clear()

                // Loops through each task
                for (taskSnapshot in snapshot.children) {
                    // Gets all task data
                    val title = taskSnapshot.child("task-name").getValue(String::class.java) ?: ""
                    val desc = taskSnapshot.child("description").getValue(String::class.java) ?: ""
                    val id = taskSnapshot.key ?: ""
                    val completed =
                        taskSnapshot.child("is-completed").getValue(Boolean::class.java) ?: false

                    val fetchedTask = Task(title, desc, id = id, isCompleted = completed)
                    tasks.add(fetchedTask)
                }

                // Refreshes UI
                onComplete()
            }.addOnFailureListener {
                // Handle failure
                onComplete()
            }
        } else {
            tasks.clear()
            onComplete()
        }
    }


    // Adds a task to the list
    fun addTask(task: Task) {
        tasks.add(task)
        writeTask(task)
    }

    // Checks if a task already exists
    fun checkTask(task: Task): Boolean {
        for (existingTask in tasks) {
            if (existingTask.task.lowercase() contentEquals task.task.lowercase()) {
                return true; // Task already exists
            }
        }
        return false; // Task does not exist
    }

    // Deletes a task from the list
    fun deleteTask(position: Int) {
        if (position >= 0 && position < tasks.size) {
            val taskToRemove = tasks[position]

            // Remove from Firebase
            Cloud.auth.currentUser?.let {
                Cloud.db.reference
                    .child("users")
                    .child(it.uid)
                    .child("task-list")
                    .child(taskToRemove.id)
                    .removeValue() // This deletes the node
            }

            // Remove from local list
            tasks.removeAt(position)
        }
    }

    // Updates a task in the list
    fun updateTask(position: Int, task: Task) {
        if (position >= 0 && position < tasks.size) {
            tasks[position] = task
            writeTask(task)
        }
    }
}