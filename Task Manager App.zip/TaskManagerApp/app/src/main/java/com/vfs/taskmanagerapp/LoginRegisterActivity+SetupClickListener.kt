package com.vfs.taskmanagerapp

// Sets up all the variables for each button/text
fun LoginRegisterActivity.setupClickListener() {
    loginButton = findViewById(R.id.btnLoginSubmit)
    registerButton = findViewById(R.id.btnRegisterSubmit)

    nameRegisterEditText = findViewById(R.id.registerName)
    emailRegisterEditText = findViewById(R.id.registerEmail)
    passwordRegisterEditText = findViewById(R.id.registerPassword)

    emailLoginEditText = findViewById(R.id.loginEmail)
    passwordLoginEditText = findViewById(R.id.loginPassword)

    statusText = findViewById(R.id.statusTextView)

    registerButton.setOnClickListener {
        handleRegister()
    }

    loginButton.setOnClickListener() {
        handleLogin()
    }
}