package com.vfs.taskmanagerapp

import android.content.Intent
import com.google.firebase.auth.UserProfileChangeRequest

fun LoginRegisterActivity.handleLogin() {

    // Gets login data
    val email = emailLoginEditText.text.toString().trim()
    val password = passwordLoginEditText.text.toString().trim()

    when {

        // Checks for valid data
        email.isEmpty() -> {
            statusText.text = "Please enter an email"
        }
        password.isEmpty() -> {
            statusText.text = "Please enter a password"
        }
        !isValidEmail(email) -> {
            statusText.text = "Please enter a valid email"
        }
        else -> {
            statusText.text = "Login successful for $email!"

            // Logs in user
            Cloud.auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener (this) { task ->
                    if (task.isSuccessful) {
                        statusText.text = "Login successful for $email!"
                        val profileUpdates = UserProfileChangeRequest.Builder()
                            .setDisplayName(Cloud.auth.currentUser?.displayName)
                            .build()

                        Cloud.auth.currentUser?.updateProfile(profileUpdates)

                        // Switches to main app screen
                        val intent = Intent(this, TaskManager::class.java)
                        startActivity(intent)
                        finish()
                    }
                    else{ // Runs if failed
                        statusText.text = "Registration failed: ${task.exception?.message}"
                    }
                }
        }
    }
}