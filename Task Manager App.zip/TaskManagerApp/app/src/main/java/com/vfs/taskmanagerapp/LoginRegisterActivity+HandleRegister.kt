package com.vfs.taskmanagerapp

import android.content.Intent
import com.google.firebase.auth.UserProfileChangeRequest

fun LoginRegisterActivity.handleRegister() {

    // Gets data input
    val username = nameRegisterEditText.text.toString().trim()
    val email = emailRegisterEditText.text.toString().trim()
    val password = passwordRegisterEditText.text.toString().trim()

    when {
        // Checks for valid information
        username.isEmpty() -> {
            statusText.text = "Please enter a username"
        }

        email.isEmpty() -> {
            statusText.text = "Please enter an email"
        }

        password.isEmpty() -> {
            statusText.text = "Please enter a password"
        }

        !isValidEmail(email) -> {
            statusText.text = "Please enter a valid email"
        }

        password.length < 6 -> {
            statusText.text = "Password must be at least 6 characters"
        }

        // Registers user
        else -> {
            statusText.text = "Registration successful for $username!"

            // Creates user to Cloud
            Cloud.auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        val profileUpdates = UserProfileChangeRequest.Builder()
                            .setDisplayName(username)
                            .build()

                        // Updates user profile and moves back to main screen
                        Cloud.auth.currentUser?.updateProfile(profileUpdates)
                            ?.addOnCompleteListener(this) { profTask ->
                                if (profTask.isSuccessful) {
                                    Cloud.writeUserAfterRegistration()

                                    val intent = Intent(this, TaskManager::class.java)
                                    startActivity(intent)
                                    finish()
                                }
                                else { }
                            }
                    } else { // Registering failed
                        statusText.text = "Registration failed: ${task.exception?.message}"
                    }
                }
        }
    }
}