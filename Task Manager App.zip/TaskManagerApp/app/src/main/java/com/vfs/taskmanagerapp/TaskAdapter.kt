package com.vfs.taskmanagerapp

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

// Task adapter that takes in list of tasks and creates a recycler view
class TaskAdapter(val taskList: List<Task>) : RecyclerView.Adapter<TaskViewHolder>()
{

    // Creates a view holder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder
    {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.task_recycler, parent, false)
        return TaskViewHolder(view)
    }

    // Adds the data to the view holder
    override fun onBindViewHolder(holder: TaskViewHolder, position: Int)
    {
        val currentTask = taskList[position]

        // Sets the task
        holder.taskCheckBox.text = currentTask.task

        // Changes the checkbox depending on if it is completed
        holder.taskCheckBox.setOnCheckedChangeListener(null)
        holder.taskCheckBox.isChecked = currentTask.isCompleted
        
        // Changes status when check box is clicked
        holder.taskCheckBox.setOnCheckedChangeListener { _, isChecked ->
            currentTask.isCompleted = isChecked
            TaskRepository.updateTask(position, currentTask)
        }

        // Sets description
        holder.descriptionTextView.text = currentTask.description

        // Handles the edit button click
        holder.editTaskButton.setOnClickListener {
            val adapterPosition = holder.bindingAdapterPosition

            // Checks if position is valid
            if (adapterPosition != RecyclerView.NO_POSITION)
            {

                // Sends data when switching to task manager
                val intent = Intent(holder.itemView.context, TaskManager::class.java).apply {
                    putExtra("task_position", adapterPosition)
                    putExtra("task_title", currentTask.task)
                    putExtra("task_description", currentTask.description)
                    putExtra("task_id", currentTask.id)
                }

                // Moves to task manager
                holder.itemView.context.startActivity(intent)
            }
        }

        // Handles the delete button click
        holder.deleteTaskButton.setOnClickListener {
            val adapterPosition = holder.bindingAdapterPosition

            // Checks if position is valid
            if (adapterPosition != RecyclerView.NO_POSITION)
            {
                // Remove the task from the task list
                TaskRepository.deleteTask(adapterPosition)
                // Updates UI
                notifyItemRemoved(adapterPosition)
            }
        }
    }

    // Gets item count
    override fun getItemCount(): Int
    {
        return taskList.size
    }
}