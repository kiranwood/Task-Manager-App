package com.vfs.taskmanagerapp

import kotlin.uuid.Uuid

// Class to create each task
data class Task(
    val task: String,
    val description: String,
    var isCompleted: Boolean = false,
    val id: String = java.util.UUID.randomUUID().toString()
)