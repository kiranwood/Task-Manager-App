package com.vfs.taskmanagerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TaskListScreen : AppCompatActivity()
{
    private var taskAdapter : TaskAdapter? = null


    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_task_list_screen)

        // Gets Add Tasks Button
        val addTasksButton = findViewById<Button>(R.id.addTasksButton_id)

        // Adds listener to move user to task manager screen
        addTasksButton.setOnClickListener {
            val intent = Intent(this, TaskManager::class.java)
            startActivity(intent)
            finish()
        }

        // Created RecyclerView
        val taskRecyclerView = findViewById<RecyclerView>(R.id.taskRecyclerView)

        // Creates adapter to display tasks from the Repository
        taskAdapter = TaskAdapter(TaskRepository.tasks)
        taskRecyclerView.adapter = taskAdapter
        taskRecyclerView.layoutManager = LinearLayoutManager(this)

        // Fetches tasks from cloud
        refreshTasks()
    }

    private fun refreshTasks() {
        TaskRepository.fetchTasksFromCloud {
            runOnUiThread {
                taskAdapter?.notifyDataSetChanged()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // This will run every time you come back to this screen
        refreshTasks()
    }
}