package com.vfs.taskmanagerapp

import android.content.Intent
import android.view.Gravity
import androidx.appcompat.app.AlertDialog

fun TaskManager.showLoginRegisterModal ()
{
    val builder = AlertDialog.Builder(this)

    // Shows alert for login or register
    builder.setTitle("Login or Register")
    builder.setMessage("Would you like to login or register?")

    // Moves to login screen
    builder.setPositiveButton("Login") { _, _ ->
        val intent = Intent(this, LoginRegisterActivity::class.java)
        intent.putExtra("type", "login")
        startActivity(intent)
        finish()
    }

    // Moves to register screen
    builder.setNegativeButton("Register") { _, _ ->
        val intent = Intent(this, LoginRegisterActivity::class.java)
        intent.putExtra("type", "register")
        startActivity(intent)
        finish()
    }

    // Cancels
    builder.setNeutralButton("Cancel" ) { _, _ ->
    }

    // Shows popup alert
    val dialog = builder.create()
    dialog.show()

    dialog.window?.setGravity((Gravity.TOP))
}